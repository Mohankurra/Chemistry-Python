@echo off
echo RDKit Molecule Analyzer
echo.
python molecule_analyzer.py
pause
