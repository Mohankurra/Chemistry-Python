from rdkit import Chem
from rdkit.Chem import Descriptors, Draw
from rdkit.Chem.rdMolDescriptors import CalcMolFormula

print("=" * 45)
print("          RDKit MOLECULE ANALYZER")
print("=" * 45)

smiles = input("\nEnter SMILES: ").strip()

mol = Chem.MolFromSmiles(smiles)

if mol is None:
    print("\nInvalid SMILES. Please try again.")
else:
    formula = CalcMolFormula(mol)
    molecular_weight = Descriptors.MolWt(mol)
    logp = Descriptors.MolLogP(mol)
    tpsa = Descriptors.TPSA(mol)
    hbd = Descriptors.NumHDonors(mol)
    hba = Descriptors.NumHAcceptors(mol)

    print("\nMolecule information")
    print("-" * 45)
    print(f"SMILES:              {smiles}")
    print(f"Formula:             {formula}")
    print(f"Molecular weight:    {molecular_weight:.3f} g/mol")
    print(f"Number of atoms:     {mol.GetNumAtoms()}")
    print(f"Heavy atoms:         {mol.GetNumHeavyAtoms()}")
    print(f"LogP:                {logp:.3f}")
    print(f"TPSA:                {tpsa:.3f} Å²")
    print(f"H-bond donors:       {hbd}")
    print(f"H-bond acceptors:    {hba}")

    image = Draw.MolToImage(mol, size=(500, 400))
    output_file = "molecule.png"
    image.save(output_file)

    print(f"\nStructure saved as:  {output_file}")
    print("\nAnalysis complete.")
