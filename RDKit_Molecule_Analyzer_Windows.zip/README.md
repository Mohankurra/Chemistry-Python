# RDKit Molecule Analyzer — Beginner Project

## What this project does

Enter a chemical SMILES string and the program calculates:

- Molecular formula
- Molecular weight
- Total number of atoms
- Number of heavy atoms
- LogP
- TPSA
- Hydrogen-bond donors
- Hydrogen-bond acceptors
- 2D molecular structure image

## Windows installation

1. Install Python from https://www.python.org/downloads/
2. Open Command Prompt.
3. Install RDKit:

```bash
pip install rdkit
```

4. Open Command Prompt in this project folder.
5. Run:

```bash
python molecule_analyzer.py
```

## Test

Enter:

```text
CCO
```

This is ethanol.

You should obtain approximately:

```text
Formula:             C2H6O
Molecular weight:    46.069 g/mol
Number of atoms:     9
Heavy atoms:         3
```

The program also creates:

```text
molecule.png
```

## Other SMILES to test

```text
C
CCO
CC(=O)O
c1ccccc1
Oc1ccccc1
CC(=O)Oc1ccccc1C(=O)O
Cn1c(=O)c2c(ncn2C)n(C)c1=O
```

## Learning objective

This project demonstrates the basic workflow:

SMILES → RDKit molecule → chemical descriptors → molecular image
